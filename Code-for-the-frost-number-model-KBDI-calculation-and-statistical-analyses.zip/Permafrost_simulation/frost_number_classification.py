"""Frozen-ground classification using annual freezing and thawing indices.

Plateau thresholds: PF ≥ 0.55, SFG ≥ 0.01; other regions:
PF ≥ 0.53, SFG ≥ 0.10, IFG ≥ 0.01. Class codes: 0, 1, 2, 3.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import xarray as xr
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from cmip6_config import MODELS, SCENARIOS


def frost_number(fi, ti):
    fi = np.asarray(fi, dtype=float); ti = np.asarray(ti, dtype=float)
    if np.any(np.isfinite(fi) & (fi < 0)) or np.any(np.isfinite(ti) & (ti < 0)):
        raise ValueError('FI and TI must be nonnegative degree-day totals.')
    denom = np.sqrt(fi) + np.sqrt(ti)
    with np.errstate(invalid='ignore', divide='ignore'):
        f = np.sqrt(fi) / denom
    return np.where(denom > 0, f, np.nan)


def classify(fi, ti, tp_mask):
    f = frost_number(fi, ti)
    m = np.asarray(tp_mask) == 1
    if f.shape != m.shape: raise ValueError('TP mask must align with FI/TI grid.')
    result = np.full(f.shape, -9999, dtype=np.int16)
    valid = np.isfinite(f) & (f >= 0) & (f <= 1)
    result[valid & m & (f < 0.01)] = 0
    result[valid & m & (f >= 0.01) & (f < 0.55)] = 2
    result[valid & m & (f >= 0.55)] = 3
    result[valid & ~m & (f < 0.01)] = 0
    result[valid & ~m & (f >= 0.01) & (f < 0.1)] = 1
    result[valid & ~m & (f >= 0.1) & (f < 0.53)] = 2
    result[valid & ~m & (f >= 0.53)] = 3
    return result


def classify_files(fi_path, ti_path, mask_path, out_path):
    with xr.open_dataset(fi_path) as a, xr.open_dataset(ti_path) as b, xr.open_dataset(mask_path) as mm:
        fi = a['FI']; ti = b['TI']; mask = mm['elevation']
        # Require matching FI, TI and mask grids.
        if fi.dims != ('lat','lon') or ti.dims != ('lat','lon') or mask.dims != ('lat','lon'):
            raise ValueError('Expected FI, TI and elevation data with dims (lat, lon).')
        if not (np.array_equal(fi.lat.values, ti.lat.values) and np.array_equal(fi.lon.values, ti.lon.values)
                and np.array_equal(fi.lat.values, mask.lat.values) and np.array_equal(fi.lon.values, mask.lon.values)):
            raise ValueError('Grid mismatch: no implicit regridding of TP mask or FI/TI is permitted.')
        result = classify(fi.values, ti.values, mask.values)
        out = xr.Dataset({'frozen': (('lat','lon'),result)}, coords={'lat': fi.lat.values,'lon':fi.lon.values})
        out['frozen'].attrs.update(long_name='frozen-ground class',
                                   _FillValue=-9999,flag_values=np.array([0,1,2,3], dtype=np.int16),
                                   flag_meanings='unfrozen intermittent seasonal permafrost')
        Path(out_path).parent.mkdir(parents=True, exist_ok=True)
        out.to_netcdf(out_path)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input-root', type=Path, required=True, help='e.g. /data, containing SSP126/FI_MODEL_YYYY.nc')
    p.add_argument('--mask',type=Path,required=True,help='GTOPOP_v4.nc with elevation==1 over TP')
    p.add_argument('--output-root',type=Path,required=True)
    p.add_argument('--models',nargs='+',default=MODELS)
    p.add_argument('--scenarios',nargs='+',default=SCENARIOS)
    p.add_argument('--start-year',type=int,default=1950)
    p.add_argument('--end-year',type=int,default=2099)
    p.add_argument('--strict',action='store_true',help='fail on missing model-year input instead of logging skip')
    a=p.parse_args()
    for scen in a.scenarios:
        sdir=a.input_root/scen.upper()
        for year in range(a.start_year,a.end_year+1):
            for model in a.models:
                fi=sdir/f'FI_{model}_{year}.nc'; ti=sdir/f'TI_{model}_{year}.nc'
                if not (fi.exists() and ti.exists()):
                    if a.strict: raise FileNotFoundError(f'Missing: {fi} or {ti}')
                    print(f'SKIP {scen} {model} {year}: missing FI/TI')
                    continue
                out=a.output_root/f'Frozen_{scen.upper()}'/f'{model}_Frozen_{scen}_{year}.nc'
                classify_files(fi,ti,a.mask,out)
            fi=sdir/f'FI_ensemble_mean_{year}.nc';ti=sdir/f'TI_ensemble_mean_{year}.nc'
            if fi.exists() and ti.exists():
                out=a.output_root/f'Frozen_{scen.upper()}'/f'Ensemble_Mean_Frozen_{scen}_{year}.nc'
                classify_files(fi,ti,a.mask,out)
            elif a.strict:raise FileNotFoundError(f'Missing index ensemble inputs: {fi} or {ti}')
    print('Finished annual FI/TI classification.')
if __name__=='__main__':main()
