"""Daily Keetch–Byram Drought Index (KBDI; 0–800).

Inputs: daily maximum temperature (°C), daily precipitation (mm), and mean
annual precipitation (mm yr-1). The temperature-dependent increment follows
the Keetch–Byram equation with the -8.30 coefficient.
Rainfall interception is applied per wet spell or per day.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np

RAIN_THRESHOLD_MM = 5.08  # 0.20 inch
MM_PER_POINT = 0.254      # KBDI is in 0.01 inch (0.254 mm) increments

@dataclass
class KBDIState:
    index: np.ndarray
    wet_spell_total_mm: np.ndarray


def initialize(shape, value=0.0):
    if not np.isfinite(value) or not 0 <= value <= 800:
        raise ValueError('Initial KBDI must be within [0, 800].')
    return KBDIState(np.full(shape, value, dtype=np.float64),
                     np.zeros(shape, dtype=np.float64))


def daily_step(state: KBDIState, tasmax_c, pr_mm, mean_annual_pr_mm,
               rainfall_mode='wet_spell'):
    """Update one daily time step; return (new_state, daily_kbdi_array).

    No units are inferred here. Unit conversion belongs to IO layer.
    With invalid cells output NaN and retain state (availability tracked).
    The rainfall reduction is computed per wet spell by default.
    """
    if rainfall_mode not in ('wet_spell', 'daily'):
        raise ValueError('rainfall_mode must be wet_spell or daily')
    q = np.asarray(state.index, dtype=np.float64)
    p = np.broadcast_to(np.asarray(pr_mm, dtype=np.float64), q.shape)
    t = np.broadcast_to(np.asarray(tasmax_c, dtype=np.float64), q.shape)
    rain_clim = np.broadcast_to(np.asarray(mean_annual_pr_mm, dtype=np.float64), q.shape)
    wet_prev = np.broadcast_to(state.wet_spell_total_mm, q.shape)
    ok = np.isfinite(q) & np.isfinite(p) & np.isfinite(t) & np.isfinite(rain_clim) & (rain_clim > 0) & (p >= 0)
    # Avoid propagating NaNs through clipping; invalid pixels retain previous state.
    p_safe = np.where(ok, p, 0.0)
    t_safe = np.where(ok, t, 0.0)
    r_safe = np.where(ok, rain_clim, 1.0)
    if rainfall_mode == 'wet_spell':
        wet_next = np.where(p_safe > 0, wet_prev + p_safe, 0.0)
        net_rain = np.where(p_safe > 0,
            np.maximum(wet_next - RAIN_THRESHOLD_MM, 0) - np.maximum(wet_prev - RAIN_THRESHOLD_MM, 0),
            0.0)
    else:
        wet_next = np.zeros_like(q)
        net_rain = np.maximum(p_safe - RAIN_THRESHOLD_MM, 0.0)
    wet_next = np.where(ok, wet_next, wet_prev)
    after_rain = np.clip(q - net_rain / MM_PER_POINT, 0, 800)
    t_f = t_safe * 9.0 / 5.0 + 32.0
    rain_inch = r_safe / 25.4
    dry_factor = (0.968 * np.exp(0.0486 * t_f) - 8.30)
    increment = (800.0 - after_rain) * np.maximum(0.0, dry_factor) * 0.001 / (1.0 + 10.88 * np.exp(-0.0441 * rain_inch))
    increment = np.where(t_safe > 10, increment, 0.0)
    computed = np.clip(after_rain + increment, 0, 800)
    result = np.where(ok, computed, np.nan)
    q_next = np.where(ok, computed, q)
    return KBDIState(q_next, wet_next), result
