"""Equal-weight multimodel ensemble of each GCM's completed annual KBDI.

"""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import xarray as xr
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from cmip6_config import MODELS, SCENARIOS

VARS=('kbdi_annual_mean','kbdi_warm_season_mean','kbdi_annual_max','kbdi_year_end')


def aggregate_files(paths,output,min_models=25,model_names=None):
    paths=[Path(p) for p in paths if Path(p).is_file()]
    if len(paths)<min_models:
        raise ValueError(f'Only {len(paths)} model outputs; min_models={min_models}. No silent incomplete MME.')
    if model_names is not None and len(model_names)!=len(paths):
        raise ValueError('Number of model labels must match file count')
    sums={};sums2={};counts={};lat=None;lon=None
    for path in paths:
        with xr.open_dataset(path) as ds:
            if lat is None:
                lat=ds.lat.values.copy();lon=ds.lon.values.copy()
            if not (np.array_equal(ds.lat.values,lat) and np.array_equal(ds.lon.values,lon)):
                raise ValueError(f'Grid mismatch at {path}; regrid before ensemble, do not rely on array positions')
            for var in VARS:
                x=ds[var].values.astype(float)
                valid=np.isfinite(x)
                if var not in sums:
                    sums[var]=np.zeros_like(x);sums2[var]=np.zeros_like(x);counts[var]=np.zeros(x.shape,dtype=np.uint16)
                sums[var]+=np.where(valid,x,0.0)
                sums2[var]+=np.where(valid,x*x,0.0)
                counts[var]+=valid.astype(np.uint16)
    out=xr.Dataset(coords={'lat':lat,'lon':lon})
    for var in VARS:
        n=counts[var].astype(float)
        with np.errstate(invalid='ignore',divide='ignore'):
            mean=np.where(n>=min_models,sums[var]/n,np.nan)
            var_sample=np.where(n>=max(2,min_models),(sums2[var]-sums[var]**2/n)/(n-1),np.nan)
            std=np.sqrt(np.maximum(0,var_sample))
        out[var+'_mme_mean']=(('lat','lon'),mean.astype('float32'))
        out[var+'_intermodel_sd']=(('lat','lon'),std.astype('float32'))
        out[var+'_n_gcms']=(('lat','lon'),counts[var])
    out.attrs.update(ensemble='equal-weight arithmetic mean of individual GCM KBDI results',
                     source_models=','.join(model_names or [p.stem for p in paths]),
                     min_models_per_cell=min_models)
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True)
    out.to_netcdf(output)
    return out


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model-output-root',required=True,type=Path)
    parser.add_argument('--output-root',required=True,type=Path)
    parser.add_argument('--models',nargs='+',default=MODELS)
    parser.add_argument('--scenarios',nargs='+',default=SCENARIOS)
    parser.add_argument('--start-year',type=int,default=2015)
    parser.add_argument('--end-year',type=int,default=2099)
    parser.add_argument('--min-models',type=int,default=25)
    args=parser.parse_args()
    if args.min_models>len(args.models):
        raise ValueError(f'min-models={args.min_models} exceeds selected model count {len(args.models)}')
    for scenario in args.scenarios:
        for year in range(args.start_year,args.end_year+1):
            by_model=[(m,args.model_output_root/scenario/f'KBDI_{m}_{scenario}_{year}.nc') for m in args.models]
            existing=[(m,p) for m,p in by_model if p.is_file()]
            output=args.output_root/scenario/f'MME_KBDI_{scenario}_{year}.nc'
            aggregate_files([p for m,p in existing],output,args.min_models,[m for m,p in existing])
            print('Wrote',output,len(existing),'models')
if __name__=='__main__':main()
