#!/usr/bin/env python3
"""Compute per-GCM daily KBDI from NEX-GDDP-CMIP6, then annual outputs.

Input NetCDF default: INPUT/{scenario}/{variable}_{model}_{year}.nc
  - {scenario} is 'historical' or one of ssp126/ssp245/ssp370/ssp585.
  - {variable} is 'tasmax' (K) or 'pr' (kg m-2 s-1), one calendar year.
  - Override path pattern to match actual NASA filenames; * wildcards accepted.

Processing (for EACH GCM):
  (1) derive reference-period mean annual rainfall (default 1981–2014) from
      historical daily 'pr', on the exact same 0.25-deg grid;
  (2) initialize at first historical spinup year (default 1950), and run daily
      KBDI through 2014, preserving rainfall / index state through years;
  (3) branch that state into each SSP and run daily 2015–2099;
  (4) write annual mean, NH warm-season mean, annual max, year-end index.

"""
from __future__ import annotations
import argparse
import csv
from pathlib import Path
import sys
import numpy as np
import xarray as xr
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from cmip6_config import MODELS, SCENARIOS
from kbdi.kbdi_core import initialize,daily_step,KBDIState
from kbdi.cmip6_io import open_pair,open_precip


def _grid_check(lat,lon,da):
    if lat is not None and not (np.array_equal(lat,da.lat.values) and np.array_equal(lon,da.lon.values)):
        raise ValueError('Grid changed across model years/scenarios; explicit regridding required.')


def rainfall_climatology(root,pattern,model,start,end,precip_units=None):
    """Historical calendar-year totals, averaged per cell with complete years only."""
    total=None;lat=lon=None;years=0
    for year in range(start,end+1):
        with open_precip(root,pattern,'historical',model,year,precip_units) as p:
            _grid_check(lat,lon,p)
            if lat is None:lat=p.lat.values.copy();lon=p.lon.values.copy()
            annual=np.zeros((len(lat),len(lon)),dtype=float)
            count=np.zeros_like(annual,dtype=np.uint16)
            for day in range(p.sizes['time']):
                value=np.asarray(p.isel(time=day).values,dtype=float)
                if np.any(np.isfinite(value)&(value<0)):
                    raise ValueError(f'Negative precipitation in {model} {year}')
                good=np.isfinite(value)
                annual+=np.where(good,value,0.0)
                count+=good.astype(np.uint16)
            annual=np.where(count==p.sizes['time'],annual,np.nan)
            total=annual if total is None else total+annual  # strict: nan propagates
            years+=1
    clim=total/years
    if not np.any(np.isfinite(clim)&(clim>0)):
        raise ValueError(f'No valid positive rainfall climatology in {model}')
    return clim,lat,lon


def run_year(root,pattern,scenario,model,year,state,rain_clim,lat,lon,
             output_root=None,rainfall_mode='wet_spell',warm_months=(5,6,7,8,9),
             temp_units=None,precip_units=None,write_daily=False):
    with open_pair(root,pattern,scenario,model,year,temp_units,precip_units) as (tasmax,precip):
        _grid_check(lat,lon,tasmax)
        sm=np.zeros_like(rain_clim);nw=np.zeros(rain_clim.shape,dtype=np.uint16)
        sw=np.zeros_like(rain_clim);nwarm=np.zeros(rain_clim.shape,dtype=np.uint16)
        annual_max=np.full_like(rain_clim,-np.inf)
        daily=[];months=np.asarray(tasmax.time.dt.month.values)
        for ix,month in enumerate(months):
            state,dayval=daily_step(state,tasmax.isel(time=ix).values,
                                    precip.isel(time=ix).values,rain_clim,rainfall_mode)
            ok=np.isfinite(dayval)
            sm+=np.where(ok,dayval,0.0);nw+=ok.astype(np.uint16)
            annual_max=np.maximum(annual_max,np.where(ok,dayval,-np.inf))
            if month in warm_months:
                sw+=np.where(ok,dayval,0.0);nwarm+=ok.astype(np.uint16)
            if write_daily: daily.append(dayval.astype('float32'))
        if output_root is not None:
            with np.errstate(divide='ignore',invalid='ignore'):
                ds=xr.Dataset({
                    'kbdi_annual_mean':(('lat','lon'),np.where(nw>0,sm/np.maximum(nw,1),np.nan).astype('float32')),
                    'kbdi_warm_season_mean':(('lat','lon'),np.where(nwarm>0,sw/np.maximum(nwarm,1),np.nan).astype('float32')),
                    'kbdi_annual_max':(('lat','lon'),np.where(nw>0,annual_max,np.nan).astype('float32')),
                    'kbdi_year_end':(('lat','lon'),np.where(nw>0,state.index,np.nan).astype('float32')),
                    'n_valid_days':(('lat','lon'),nw),
                    'annual_rain_climatology_mm':(('lat','lon'),rain_clim.astype('float32')),
                },coords={'lat':lat,'lon':lon})
            ds.attrs.update(gcm=model,experiment=scenario,year=year,
                            rainfall_interception=rainfall_mode,
                            warm_months=','.join(map(str,warm_months)),
                            initial_condition='KBDI initialized at historical spinup start; state carried across years',
                            kbdi_units='index 0..800, 0.01 inch water deficit',
                            method='Keetch-Byram Drought Index (KBDI)')
            path=Path(output_root)/scenario/f'KBDI_{model}_{scenario}_{year}.nc'
            path.parent.mkdir(parents=True,exist_ok=True);ds.to_netcdf(path)
            if write_daily:
                dds=xr.Dataset({'kbdi':(('time','lat','lon'),np.stack(daily))},
                        coords={'time':tasmax.time.values,'lat':lat,'lon':lon})
                dds.attrs.update(ds.attrs)
                dds.to_netcdf(path.with_name(path.stem+'_daily.nc'))
        return state


def simulate_model(args,model):
    clim,lat,lon=rainfall_climatology(args.input_root,args.file_template,model,
                   args.baseline_start,args.baseline_end,args.precip_units)
    state=initialize(clim.shape,args.initial_kbdi)
    for year in range(args.historical_start,args.historical_end+1):
        state=run_year(args.input_root,args.file_template,'historical',model,year,state,
             clim,lat,lon,output_root=args.output_root if args.write_historical else None,
             rainfall_mode=args.rainfall_mode,warm_months=args.warm_months,
             temp_units=args.temp_units,precip_units=args.precip_units,
             write_daily=args.output_daily and args.write_historical)
        if args.verbose:print(f'Historical {model} {year}',flush=True)
    base_state=KBDIState(state.index.copy(),state.wet_spell_total_mm.copy())
    for scenario in args.scenarios:
        state=KBDIState(base_state.index.copy(),base_state.wet_spell_total_mm.copy())
        for year in range(args.historical_end+1,args.end_year+1):
            state=run_year(args.input_root,args.file_template,scenario,model,year,state,
                 clim,lat,lon,output_root=args.output_root if year>=args.start_year else None,
                 rainfall_mode=args.rainfall_mode,warm_months=args.warm_months,
                 temp_units=args.temp_units,precip_units=args.precip_units,
                 write_daily=args.output_daily and year>=args.start_year)
            if args.verbose:print(f'{scenario} {model} {year}',flush=True)
    return True


def get_args(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input-root',required=True,type=Path)
    p.add_argument('--output-root',required=True,type=Path)
    p.add_argument('--file-template',default='{scenario}/{variable}_{model}_{year}.nc',
                   help='Relative path pattern; template keys {scenario},{SCENARIO},{variable},{model},{year}; glob * allowed')
    p.add_argument('--models',nargs='+',default=MODELS)
    p.add_argument('--scenarios',nargs='+',default=SCENARIOS)
    p.add_argument('--historical-start',type=int,default=1950)
    p.add_argument('--historical-end',type=int,default=2014)
    p.add_argument('--baseline-start',type=int,default=1981)
    p.add_argument('--baseline-end',type=int,default=2014)
    p.add_argument('--start-year',type=int,default=2015,help='First scenario year to SAVE, earlier years still simulated for state')
    p.add_argument('--end-year',type=int,default=2099)
    p.add_argument('--initial-kbdi',type=float,default=0.,help='Initial KBDI on first historical day (default 0)')
    p.add_argument('--rainfall-mode',choices=['wet_spell','daily'],default='wet_spell')
    p.add_argument('--warm-months',type=int,nargs='+',default=[5,6,7,8,9],help='Northern-Hemisphere example: May-Sept')
    p.add_argument('--temp-units',choices=['K','C'],help='Explicit tasmax unit override')
    p.add_argument('--precip-units',choices=['flux','mm-day'],help='Override missing/wrong pr units')
    p.add_argument('--write-historical',action='store_true')
    p.add_argument('--output-daily',action='store_true',help='May require substantial memory/disk on global grids')
    p.add_argument('--allow-missing-models',action='store_true',help='Skip failing models, with explicit warnings')
    p.add_argument('--verbose',action='store_true')
    args=p.parse_args(argv)
    if not (args.historical_start<=args.baseline_start<=args.baseline_end<=args.historical_end<args.start_year<=args.end_year):
        raise ValueError('Require historical_start <= baseline_start <= baseline_end <= historical_end < start_year <= end_year')
    if args.end_year>2100:raise ValueError('Unexpected projection year >2100; verify scenario file coverage.')
    if any(m<1 or m>12 for m in args.warm_months):raise ValueError('warm-months must be 1..12')
    return args


def main(argv=None):
    args=get_args(argv)
    args.output_root.mkdir(parents=True,exist_ok=True)
    failures=[];success=[]
    for model in args.models:
        print('Starting GCM',model,flush=True)
        try:
            simulate_model(args,model)
        except Exception as e:
            failures.append((model,str(e)))
            print('ERROR',model,str(e),flush=True)
            if not args.allow_missing_models:raise
        else:
            success.append(model);print('DONE',model,flush=True)
    with (args.output_root/'run_models.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['model','status','message'])
        for model in args.models:
            error=next((e for m,e in failures if m==model),'')
            w.writerow([model,'FAILED' if error else 'SUCCESS',error])
    print(f'Completed {len(success)}/{len(args.models)} models. Run ensemble.py next.')
    if failures:print('WARNING: incomplete GCM coverage:',failures)
if __name__=='__main__':main()
