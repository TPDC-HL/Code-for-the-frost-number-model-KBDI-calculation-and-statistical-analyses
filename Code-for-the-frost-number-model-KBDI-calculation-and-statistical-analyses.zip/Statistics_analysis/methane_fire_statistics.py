#!/usr/bin/env python3
"""Negative binomial regression and within-year circular-shift permutation test.

Daily observations are selected for March–April 2017–2019. The regression
includes methane concentration, air temperature, relative humidity, calendar-
year indicators and a cubic day-of-season polynomial.
"""
from __future__ import annotations
import argparse
import csv
import math
import warnings
from datetime import datetime, timedelta, date
from pathlib import Path

import numpy as np
from scipy.optimize import minimize_scalar
from scipy.stats import norm
import statsmodels.api as sm
from xlsx_reader import read_xlsx_grid

INPUT_COLUMNS = {
    "date": "日期", "fire": "火点个数", "temperature": "温度",
    "humidity": "湿度", "ch4_r1": "CH4-1(R-1)", "ch4_r2": "CH4-1(R-2)",
}
WIND_HEADERS = ["风速", "平均风速", "风速(m/s)", "wind_speed", "wind"]

def as_date(v):
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    if isinstance(v, (int, float)):
        return (datetime(1899, 12, 30) + timedelta(days=float(v))).date()
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%Y.%m.%d"):
        try:
            return datetime.strptime(str(v).strip()[:10], fmt).date()
        except ValueError:
            pass
    raise ValueError(f"Unrecognized date: {v!r}")


def number(v):
    if v is None or str(v).strip() in ("", "--", "NA", "nan", "None"):
        return float("nan")
    try:
        return float(v)
    except (ValueError, TypeError):
        return float("nan")


def read_rows(xlsx, wind_csv=None):
    grid = read_xlsx_grid(xlsx, sheet=0)
    columns = [str(h).strip() if h is not None else "" for h in grid[0]]
    idx = {h: i for i, h in enumerate(columns)}
    missing = [name for name in INPUT_COLUMNS.values() if name not in idx]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    wind_header = next((h for h in WIND_HEADERS if h in idx), None)
    add_wind = {}
    if wind_csv:
        with open(wind_csv, encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            if not {"日期", "风速"}.issubset(set(reader.fieldnames or [])):
                raise ValueError("wind CSV needs columns: 日期,风速")
            for row in reader:
                add_wind[as_date(row["日期"])] = number(row["风速"])
    items = []
    for row in grid[1:]:
        if len(row) < len(columns) or row[idx["日期"]] is None:
            continue
        d = as_date(row[idx["日期"]])
        if d.year not in (2017, 2018, 2019) or d.month not in (3, 4):
            continue
        vals = {key: number(row[idx[col]]) for key, col in INPUT_COLUMNS.items() if key != "date"}
        vals["date"] = d
        vals["wind"] = (add_wind.get(d, float("nan")) if wind_csv else
                        number(row[idx[wind_header]]) if wind_header else float("nan"))
        items.append(vals)
    items.sort(key=lambda z: z["date"])
    if len({z["date"] for z in items}) != len(items):
        raise ValueError("Duplicate date entries found; resolve before proceeding.")
    return items, (wind_header is not None or bool(wind_csv))


def design(items, ch4_col, use_wind=False, exclude_capped=False):
    needed = ("fire", "temperature", "humidity", ch4_col) + (("wind",) if use_wind else ())
    use = [r for r in items if all(np.isfinite(r[c]) for c in needed)
           and (not exclude_capped or r[ch4_col] < 1000)]
    if len(use) < 50:
        raise ValueError(f"Only {len(use)} complete days for {ch4_col}; insufficient for planned models")
    d = [r["date"] for r in use]
    y = np.asarray([r["fire"] for r in use], float)
    methane = np.asarray([r[ch4_col] for r in use], float)
    if np.any(y < 0) or not np.all(y == np.floor(y)):
        raise ValueError("Fire counts must be nonnegative integers")
    if np.any(methane < 0):
        raise ValueError("Methane concentrations must be nonnegative")
    temp = np.asarray([r["temperature"] for r in use], float)
    humidity = np.asarray([r["humidity"] for r in use], float)
    wind = np.asarray([r["wind"] for r in use], float) if use_wind else None
    yr = np.asarray([r.year for r in d])
    # March 1 = day 0. Values in [0,60]; shift + scale to reduce collinearity.
    seasonal_day = np.asarray([(r - date(r.year, 3, 1)).days for r in d], float)
    x = (seasonal_day - 30) / 30
    # Year fixed effects and cubic day-of-season smooth (same form each year)
    baseline = [np.ones(len(use)), temp, humidity / 10,
                (yr == 2018).astype(float), (yr == 2019).astype(float),
                x, x*x, x*x*x]
    labels = ["Intercept", "Temperature (per °C)", "RH (per 10 pct points)",
              "Year 2018", "Year 2019", "Day", "Day²", "Day³"]
    if use_wind:
        baseline.insert(3, wind)
        labels.insert(3, "Wind speed (per unit)")
    Z = np.column_stack(baseline)
    X = np.column_stack((Z[:, :1], np.log1p(methane), Z[:, 1:]))
    return {"rows": use, "dates": d, "y": y, "methane": methane, "Z": Z,
            "X": X, "years": yr, "names": ["Intercept", "ln(1+CH4)"]+labels[1:],
            "ch4_col": ch4_col, "use_wind": use_wind}


def fit_nb(y, X, alpha=None, robust=True):
    # GLM NB with profiled dispersion is much more numerically stable than joint
    # discrete-NB MLE for very sparse (zero-heavy), highly overdispersed fire counts.
    if alpha is None:
        def loss(log_alpha):
            try:
                fit = sm.GLM(y, X, family=sm.families.NegativeBinomial(alpha=np.exp(log_alpha))).fit(maxiter=200)
                return -float(fit.llf) if np.isfinite(fit.llf) else 1e30
            except Exception:
                return 1e30
        opt = minimize_scalar(loss, method="bounded", bounds=(math.log(0.1), math.log(1000)),
                              options={"xatol": 0.005})
        if not opt.success:
            warnings.warn("NB dispersion profiling did not converge")
        alpha = float(np.exp(opt.x))
    fit = sm.GLM(y, X, family=sm.families.NegativeBinomial(alpha=alpha)).fit(
        maxiter=150, **({"cov_type": "HC0"} if robust else {}))
    return fit, alpha


def permute_methane_nb(dat, alpha, observed_beta, B, rng):
    # Freedman-Lane-style residual circular shift within each year to preserve
    # original CH4~weather/season relationship and serial dependence within spring.
    Z, X = dat["Z"], dat["X"]
    fitx = sm.OLS(np.log1p(dat["methane"]), Z).fit()
    pred, resid = fitx.fittedvalues, fitx.resid
    years = dat["years"]
    groups = [np.where(years == k)[0] for k in sorted(set(years))]
    betas = []
    for _ in range(B):
        rr = resid.copy()
        for ix in groups:
            rr[ix] = np.roll(resid[ix], rng.integers(1, len(ix)))
        Xp = X.copy()
        Xp[:, 1] = pred + rr
        try:
            out, _ = fit_nb(dat["y"], Xp, alpha=alpha, robust=False)
            if np.isfinite(out.params[1]):
                betas.append(float(out.params[1]))
        except Exception:
            pass
    p_emp = (1+sum(abs(t)>=abs(observed_beta) for t in betas))/(len(betas)+1)
    return float(p_emp), len(betas)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True, type=Path)
    parser.add_argument('--output-dir', default=Path('results/methane'), type=Path)
    parser.add_argument('--permutations', type=int, default=1000)
    parser.add_argument('--seed', type=int, default=20261109)
    args = parser.parse_args()
    if args.permutations < 1:
        raise ValueError('permutations must be positive')
    args.output_dir.mkdir(parents=True, exist_ok=True)
    rows, _ = read_rows(args.input)
    results = []
    for sensor, col in [('R-1', 'ch4_r1'), ('R-2', 'ch4_r2')]:
        data = design(rows, col, use_wind=False)
        regression, alpha = fit_nb(data['y'], data['X'])
        beta, se = float(regression.params[1]), float(regression.bse[1])
        p_wald = float(2 * norm.sf(abs(beta/se)))
        p_temporal, n_perm = ('', 0)
        if sensor == 'R-1':
            p_temporal, n_perm = permute_methane_nb(
                data, alpha, beta, args.permutations, np.random.default_rng(args.seed)
            )
        results.append({
            'sensor': sensor, 'n_days': len(data['y']), 'alpha': alpha,
            'beta_ln1pCH4': beta, 'robust_se': se,
            'wald_p_two_sided': p_wald,
            'temporal_shift_p': p_temporal, 'valid_permutations': n_perm,
        })

    outfile = args.output_dir / 'methane_fire_statistics.csv'
    with outfile.open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=list(results[0].keys()))
        writer.writeheader()
        writer.writerows(results)
    for entry in results:
        print(entry)
    print('Saved:', outfile)


if __name__ == '__main__':
    main()
