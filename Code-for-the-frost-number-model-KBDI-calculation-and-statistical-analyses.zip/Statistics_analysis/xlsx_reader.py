from __future__ import annotations
from pathlib import Path
from zipfile import ZipFile
import re
import xml.etree.ElementTree as ET

_N='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
_R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
_P='http://schemas.openxmlformats.org/package/2006/relationships'


def col_index(addr: str) -> int:
    """Convert an Excel cell label such as AB123 to zero-based column index."""
    m=re.match(r'([A-Z]+)',addr.upper())
    if not m:
        raise ValueError(f'Invalid cell reference: {addr}')
    n=0
    for ch in m.group(1):n=n*26+ord(ch)-ord('A')+1
    return n-1


def read_xlsx_grid(filename, *, sheet='Sheet1', max_row=None, max_col=None):
    """Return 2-D cell values with None for missing values (1-based row/col caps).

    `sheet` may be a sheet name or zero-based index. Numeric values are float or
    int; Excel date serials remain numeric and are handled by the caller.
    """
    filename=Path(filename)
    with ZipFile(filename) as z:
        wb=ET.fromstring(z.read('xl/workbook.xml'))
        relations=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        relmap={e.attrib['Id']:e.attrib['Target'] for e in relations.findall(f'{{{_P}}}Relationship')}
        sheets=wb.find(f'{{{_N}}}sheets')
        all_sheets=list(sheets.findall(f'{{{_N}}}sheet'))
        if isinstance(sheet,int):
            sh=all_sheets[sheet]
        else:
            sh=next((x for x in all_sheets if x.attrib.get('name')==sheet),None)
            if sh is None:
                raise KeyError(f'Worksheet {sheet!r} not found in {filename}')
        rel_id=sh.attrib[f'{{{_R}}}id']
        target=relmap[rel_id].replace('\\','/')
        if target.startswith('/'):
            path=target.lstrip('/')
        elif target.startswith('xl/'):
            path=target
        else:
            path='xl/'+target
        path=str(Path(path))
        if path not in z.namelist():
            raise FileNotFoundError(f'Worksheet target missing from XLSX: {path}')
        shared=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            ss=ET.fromstring(z.read('xl/sharedStrings.xml'))
            for si in ss.findall(f'{{{_N}}}si'):
                shared.append(''.join(t.text or '' for t in si.iter(f'{{{_N}}}t')))
        xml=ET.fromstring(z.read(path))
        rows={}
        used_columns=0
        for row in xml.findall(f'.//{{{_N}}}sheetData/{{{_N}}}row'):
            rownum=int(row.attrib.get('r',len(rows)+1))
            if max_row is not None and rownum>max_row:continue
            out={}
            for c in row.findall(f'{{{_N}}}c'):
                addr=c.attrib.get('r')
                if not addr:continue
                col=col_index(addr)
                if max_col is not None and col>=max_col:continue
                v=c.find(f'{{{_N}}}v')
                inline=c.find(f'{{{_N}}}is')
                typ=c.attrib.get('t','n')
                if typ=='s' and v is not None and v.text is not None:
                    value=shared[int(v.text)]
                elif typ=='inlineStr' and inline is not None:
                    value=''.join(t.text or '' for t in inline.iter(f'{{{_N}}}t'))
                elif typ=='b' and v is not None:
                    value=v.text=='1'
                elif typ in ('str','e','d') and v is not None:
                    value=v.text
                elif v is not None and v.text not in (None,''):
                    try:
                        n=float(v.text)
                        value=int(n) if n.is_integer() and abs(n)<2**53 else n
                    except ValueError:
                        value=v.text
                else:
                    value=None
                out[col]=value
                used_columns=max(used_columns,col+1)
            rows[rownum]=out
        nrows=max_row if max_row is not None else max(rows,default=0)
        ncols=max_col if max_col is not None else used_columns
        grid=[]
        for i in range(1,nrows+1):
            d=rows.get(i,{})
            grid.append([d.get(j) for j in range(ncols)])
        return grid
